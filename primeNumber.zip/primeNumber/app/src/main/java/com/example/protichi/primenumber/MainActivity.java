package com.example.protichi.primenumber;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView Prime = (TextView)findViewById(R.id.prime);
        Random r = new Random();

        Prime.setText(String.valueOf(r.nextInt(1000)) );

        Button hint = (Button) findViewById(R.id.hint);
        hint.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                //signIn();
                // Perform action on click
                Intent hintActivity =
                        new Intent(MainActivity.this, Hint.class);
                startActivity(hintActivity);
            }
        });

        Button ans = (Button) findViewById(R.id.ans);
        ans.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                //signIn();
                // Perform action on
                Intent ansActivity =
                        new Intent(MainActivity.this, Answer.class);

                /* put prime number check here*/
                ansActivity.putExtra("ans", "yes");

                startActivity(ansActivity);

            }
        });

        Button yes = (Button) findViewById(R.id.yes);
        yes.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                //signIn();
                // Perform action on click
                Toast.makeText(MainActivity.this, "Yes", Toast.LENGTH_LONG).show();
            }
        });

        Button no = (Button) findViewById(R.id.no);
        no.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                //signIn();
                // Perform action on click
                Toast.makeText(MainActivity.this, "No", Toast.LENGTH_LONG).show();
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
